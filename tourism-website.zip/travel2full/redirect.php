<!-- include session code here -->

<!DOCTYPE html>

<html lang="en">
	
	<!-- HEAD TAG STARTS --><head>
	
  		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	
		<title>Flight Search | tourism_management</title>
    
    	<link href="css/main.css" rel="stylesheet">
    	<link href="css/bootstrap.min.css" rel="stylesheet">
    	<link href="https://fonts.googleapis.com/css?family=Oswald:200,300,400|Raleway:100,300,400,500|Roboto:100,400,500,700" rel="stylesheet">
    	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    
    	<script src="js/jquery-3.2.1.min.js"></script>
    	<script src="js/main.js"></script>
    	<script src="js/bootstrap.min.js"></script>
    	<script type="text/javascript">
			setTimeout(function(){location.href="payment.php"} , 2500);   
		</script>
    	
	</head>
	
	<!-- HEAD TAG ENDS -->
	
	<!-- BODY TAG STARTS -->
	
	<body>
	
	<div class="col-sm-12 text-center">
	
	<div class="redirect">
		
		<img src="images/loader.gif"/>
			
		<div class="text">
			
			Redirecting you to the payment page.
			
		</div>
		
		</div>
		
	</div> 
			
	</body>
	
	<!-- BODY TAG ENDS -->
	
</html>